/**
 * Options manager and parameters for tweaking fine grained agent runtime settings.
 */
package org.nhindirect.trustbundle.options;