package sit.portal.directtransport.services.model;

public class jsMetaData {
	private String description;
	private String serverpath;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getServerPath() {
		return serverpath;
	}
	public void setServerPath(String serverPath) {
		this.serverpath = serverPath;
	} 
	
}
