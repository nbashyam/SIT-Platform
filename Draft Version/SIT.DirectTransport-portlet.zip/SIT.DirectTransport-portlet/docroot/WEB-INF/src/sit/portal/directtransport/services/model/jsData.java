package sit.portal.directtransport.services.model;

public class jsData {
	private String title;
	private jsTreeAttribute attr;
	private String icon;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public jsTreeAttribute getAttr() {
		return attr;
	}
	public void setAttr(jsTreeAttribute attr) {
		this.attr = attr;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
}
