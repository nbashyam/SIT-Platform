package sit.hook;


import javax.mail.internet.InternetAddress;

import com.liferay.portal.ModelListenerException;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.model.BaseModelListener;
import com.liferay.portal.model.User;
import com.liferay.util.mail.MailEngine;
import com.liferay.util.mail.MailEngineException;

public class UserCreationHook extends BaseModelListener<User> {
	
	public void onAfterCreate(User model) throws ModelListenerException {
		User newUser = model;
	       //construct a new email.
	       StringBuilder templatesb = new StringBuilder();
	       templatesb.append("<h1><span style=\"font-size:14px;\">Dear Administrators,</span></h1><p>");
	       templatesb.append("A new user has applied for membership of SIT portal,</p>");
	       templatesb.append("<p>User email:{@EMAIL};</p><p>User screen name:{@USERNAME}</p>");
	       templatesb.append("<p>Please review the request and add user to the site.</p>");
	       
	       
	       MailMessage mailMessage = new MailMessage();
        mailMessage.setHTMLFormat(true);
        mailMessage.setBody(
     		   templatesb.toString()
     		   		.replace("{@EMAIL}", newUser.getEmailAddress())
     		   		.replace("{@USERNAME}",newUser.getScreenName())
     		   );
        mailMessage.setHTMLFormat(true);
        try {
     	   mailMessage.setFrom(new InternetAddress("tangyedong@gmail.com","SIT SYS"));
			   mailMessage.setSubject("New user has been created.");
            mailMessage.setTo(new InternetAddress("nagesh.bashyam@drajer.com"));
            mailMessage.setCC(new InternetAddress("tangyedong@gmail.com"));
        }
        catch (Exception e)
        {
        	e.printStackTrace();
		   }
       
        
			 
        try {
			MailEngine.send(mailMessage);
		} catch (MailEngineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}
	
}

